package com.example.krishnendhu.main_project;
/**
 * Created by krishnendhu on 11-04-2017.
 */
import android.content.Context;
import android.content.res.Resources;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static android.R.attr.path;

class Vertex implements Comparable<Vertex>
{
    public String name;
    //public boolean visited;
    public List<Edge> adjaceniesList;
    public double minDistance = Double.MAX_VALUE;
    public Vertex previousVertex;

    public Vertex(String name)
    {
        this.name=name;
        this.adjaceniesList=new ArrayList<>();
    }

    public void addEdge(Edge edge) {
        adjaceniesList.add(edge);
    }

    /*public void setPreviousVertex(Vertex previousVertex)
    {
        previousVertex=previousVertex;
    }*/

    @Override
    public int compareTo(Vertex other)
    {
        return Double.compare(minDistance, other.minDistance);
    }
}
class Edge {
    public  double weight;
    public final Vertex startVertex;
    public final Vertex targetVertex;
    public Edge(double argWeight, Vertex argStartVertex, Vertex argTargetVertex)
    {
        weight=argWeight;
        startVertex=argStartVertex;
        targetVertex=argTargetVertex;
    }
}

public class BellmanFord {
    public  static List<Vertex> vertexList;
    public  static List<Edge> edgeList;

    Resources resources;
    private Context c;
    public BellmanFord(Context c,List<Vertex> vertexList, List<Edge> edgeList){
        this.c = c;
        resources = this.c.getResources();
        this.vertexList=vertexList;
        this.edgeList=edgeList;
    }

   /* public BellmanFord(List<Vertex> vertexList, List<Edge> edgeList) {
        this.vertexList=vertexList;
        this.edgeList=edgeList;
    }*/

    public  static void shortestPath(Vertex sourceVertex) {
        sourceVertex.minDistance=0;

        int length=vertexList.size();

        for(int i=0;i<length-1;i++) {

            for(Edge e : edgeList) {

                if(e.startVertex.minDistance == Double.MAX_VALUE) continue;

                Vertex v= e.startVertex;
                Vertex u= e.targetVertex;

                double newDistance = v.minDistance + e.weight;

                if(newDistance < u.minDistance )
                {
                    u.minDistance=newDistance;
                    u.previousVertex=v;

                }
            }
        }

        /*for(Edge edge : this.edgeList) {
            if( edge.getStartVertex().getMinDistance()!= Double.MAX_VALUE) {
                if(hasCycle(edge)) {

                }
            }
        }*/
    }

    public static List<String> getShortestPathTo(Vertex target)
    {
        List<String> path = new ArrayList<String>();
        for (Vertex vertex = target; vertex != null; vertex = vertex.previousVertex)
            path.add(vertex.name);
        Collections.reverse(path);
        return path;
    }

    public static String mainMethod(Context c,String inp, String dst)
    {

        String temp_string2=dst.trim();
        String temp_string1="";
        int i=Integer.parseInt(inp);

        vertexList=new ArrayList<>();

        vertexList.add(new Vertex("1"));
        vertexList.add(new Vertex("2"));
        vertexList.add(new Vertex("3"));
        vertexList.add(new Vertex("4"));
        vertexList.add(new Vertex("5"));

        edgeList = new ArrayList<>();

        edgeList.add(new Edge(576, vertexList.get(0), vertexList.get(1)));
        edgeList.add(new Edge(303, vertexList.get(1), vertexList.get(2)));
        edgeList.add(new Edge(305, vertexList.get(0), vertexList.get(3)));
        edgeList.add(new Edge(576, vertexList.get(3), vertexList.get(4)));
        edgeList.add(new Edge(2, vertexList.get(4), vertexList.get(2)));

        BellmanFord al=new BellmanFord(c,vertexList,edgeList);
        //if(inp.equals("1"))
         shortestPath(vertexList.get(i-1));

        //specific rout making
        for (Vertex v : vertexList)
        {
            List<String> path = getShortestPathTo(v);
            if(v.name.equals(dst.trim())){
                temp_string1+=path;
            }
        }


        return temp_string1;
        // temp_string1="hi";
        // return temp_string1;
    }
}