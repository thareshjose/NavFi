package com.example.krishnendhu.main_project;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import com.google.zxing.Result;
import me.dm7.barcodescanner.zxing.ZXingScannerView;

import static com.example.krishnendhu.main_project.R.id.txtResult;

public class Floor_scan extends Activity implements ZXingScannerView.ResultHandler{

    private ZXingScannerView mScannerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // setContentView(R.layout.activity_main);
        mScannerView = new ZXingScannerView(this);
        setContentView(mScannerView);
        mScannerView.setResultHandler(this);
        mScannerView.startCamera();
    }

/*
    @Override
    protected void onPause() {
        super.onPause();
        mScannerView.stopCamera();
    }*/


    @Override
    public void handleResult(Result result) {
        //Vibrator vibrator=(Vibrator)getApplicationContext().getSystemService(Context.VIBRATOR_SERVICE);
        // vibrator.vibrate(300);
        //txtResult.setText(qrcodes.valueAt(0).displayValue);
        RoutCalculator routCalculator=new RoutCalculator(Floor_scan.this);
        String temp_o=""+String.valueOf(result.getText());
        //txtResult.setText(temp_o);
        String temp_o2="3";
        //temp_o="1";
        //System.out.println(temp_o);
        //Toast.makeText(Floor_scan.this, (String)temp_o,Toast.LENGTH_LONG).show();



        String start_position = routCalculator.rout_position(temp_o.trim());//start circle
        String end_position=routCalculator.rout_position(temp_o2);//end circle

        //BellmanFord path_map = new BellmanFord(Floor_scan.this);
        //BellmanFord path_map = new BellmanFord(Floor_scan.this,temp_o.trim(),temp_o2);
        String path_map_result = BellmanFord.mainMethod(Floor_scan.this,temp_o.trim(),temp_o2);

        /*String mid_position=routCalculator.rout_position_move_to(temp_o.trim())+//start position
                routCalculator.rout_path(temp_o.trim(),temp_o2,path_map_result)//path generation
                +routCalculator.rout_position_line_to(temp_o2);//end position*/

        String mid_position=routCalculator.rout_path(temp_o.trim(),temp_o2,path_map_result);

        Intent intent=new Intent(Floor_scan.this, FloorMap.class);
        intent.putExtra("start_location",start_position);
        intent.putExtra("end_location",end_position);
        intent.putExtra("mid_location",mid_position);
        startActivity(intent);

        // Toast.makeText(Floor_scan.this, (String)temp_o,Toast.LENGTH_LONG).show();

        //Intent intent=new Intent(FloorScan.this,FloorMap.class);
        // startActivity(intent);
    }


}